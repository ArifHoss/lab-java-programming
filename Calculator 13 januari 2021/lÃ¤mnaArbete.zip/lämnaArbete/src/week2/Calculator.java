
package week2;

public class Calculator {
    public static void addition(double x, double y){
        System.out.println("Addition result:"+(x+y));
    }
    public static void multiply(double x, double y){
        System.out.println("Multiply result: "+(x*y));
    }
    public static void division(double x, double y){
        System.out.println("Division result: "+(x/y));
    }
    public static void subtruction(double x, double y){
        System.out.println("Subtruction resutl: "+(x-y));
    }
    
}
