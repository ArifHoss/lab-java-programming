
package week2;

public class CalculatorSwitch {//klass namn borjar altid med stor bokstaver
    public static void addtion(double a, double b){//
        System.out.println("Your addition result is: "+(a+b));
    }
    public static void multiply(double a, double b){// 
        System.out.println("Your multiply result is: "+(a*b));
    }
    public static void division(double a, double b){//void addtion metoder return ingentin
        System.out.println("Your division result is: "+(a/b));
    }
    public static void substruction(double a, double b){
        System.out.println("Your substruction result is: "+(a-b));
    }
    
}
